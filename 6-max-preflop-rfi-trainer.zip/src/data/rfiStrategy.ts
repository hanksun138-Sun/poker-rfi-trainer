export type Position = 'UTG' | 'MP' | 'CO' | 'BTN' | 'SB';

export interface Card {
  rank: string; // '2'-'9', 'T', 'J', 'Q', 'K', 'A'
  suit: 's' | 'h' | 'd' | 'c'; // spades, hearts, diamonds, clubs
}

export interface Combo {
  card1: Card;
  card2: Card;
  handStr: string; // e.g. "AKs", "AKo", "AA"
}

export interface MixedFreq {
  raise: number;
  fold: number;
}

export interface PositionStrategy {
  raise: string[];
  mixed: Record<string, MixedFreq>;
  fold: string[];
}

export const RFI_STRATEGY: Record<Position, PositionStrategy> = {
  "UTG": {
    "raise": ["77","88","99","A3s","A4s","A5s","A6s","A7s","A8s","A9s","AA","AJo","AJs","AKo","AKs","AQo","AQs","ATo","ATs","JJ","JTs","K9s","KJs","KK","KQo","KQs","KTs","Q9s","QJs","QQ","QTs","T9s","TT"],
    "mixed": {"K8s":{"raise":0.5,"fold":0.5},"K5s":{"raise":0.5,"fold":0.5},"QJo":{"raise":0.5,"fold":0.5},"J9s":{"raise":0.5,"fold":0.5},"KTo":{"raise":0.5,"fold":0.5},"66":{"raise":0.5,"fold":0.5}},
    "fold": ["22","32o","32s","33","42o","42s","43o","43s","44","52o","52s","53o","53s","54o","54s","55","62o","62s","63o","63s","64o","64s","65o","65s","72o","72s","73o","73s","74o","74s","75o","75s","76o","76s","82o","82s","83o","83s","84o","84s","85o","85s","86o","86s","87o","87s","92o","92s","93o","93s","94o","94s","95o","95s","96o","96s","97o","97s","98o","98s","A2o","A2s","A3o","A4o","A5o","A6o","A7o","A8o","A9o","J2o","J2s","J3o","J3s","J4o","J4s","J5o","J5s","J6o","J6s","J7o","J7s","J8o","J8s","J9o","JTo","K2o","K2s","K3o","K3s","K4o","K4s","K5o","K6o","K6s","K7o","K7s","K8o","K9o","KJo","Q2o","Q2s","Q3o","Q3s","Q4o","Q4s","Q5o","Q5s","Q6o","Q6s","Q7o","Q7s","Q8o","Q8s","Q9o","QTo","T2o","T2s","T3o","T3s","T4o","T4s","T5o","T5s","T6o","T6s","T7o","T7s","T8o","T8s","T9o"]
  },
  "MP": {
    "raise": ["54s","65s","66","76s","77","87s","88","98s","99","A2s","A3s","A4s","A5s","A6s","A7s","A8s","A9s","AA","AJo","AJs","AKo","AKs","AQo","AQs","ATo","ATs","JJ","JTs","K6s","K7s","K8s","K9s","KJs","KK","KQs","KTs","Q9s","QJs","QQ","QTs","T9s","TT"],
    "mixed": {"K5s":{"raise":0.5,"fold":0.5},"Q8s":{"raise":0.5,"fold":0.5},"J9s":{"raise":0.5,"fold":0.5},"QTo":{"raise":0.5,"fold":0.5},"JTo":{"raise":0.5,"fold":0.5},"T8s":{"raise":0.5,"fold":0.5},"A9o":{"raise":0.5,"fold":0.5},"55":{"raise":0.5,"fold":0.5}},
    "fold": ["22","32o","32s","33","42o","42s","43o","43s","44","52o","52s","53o","53s","54o","62o","62s","63o","63s","64o","64s","65o","72o","72s","73o","73s","74o","74s","75o","75s","76o","82o","82s","83o","83s","84o","84s","85o","85s","86o","86s","87o","92o","92s","93o","93s","94o","94s","95o","95s","96o","96s","97o","97s","98o","A2o","A3o","A4o","A5o","A6o","A7o","A8o","J2o","J2s","J3o","J3s","J4o","J4s","J5o","J5s","J6o","J6s","J7o","J7s","J8o","J8s","J9o","K2o","K2s","K3o","K3s","K4o","K4s","K5o","K6o","K7o","K8o","K9o","KJo","KQo","KTo","Q2o","Q2s","Q3o","Q3s","Q4o","Q4s","Q5o","Q5s","Q6o","Q6s","Q7o","Q7s","Q8o","Q9o","QJo","T2o","T2s","T3o","T3s","T4o","T4s","T5o","T5s","T6o","T6s","T7o","T7s","T8o","T9o"]
  },
  "CO": {
    "raise": ["33","44","54s","55","65s","66","76s","77","87s","88","97s","98s","99","A2s","A3s","A4s","A5o","A5s","A6s","A7s","A8s","A9o","A9s","AA","AJo","AJs","AKo","AKs","AQo","AQs","ATo","ATs","J8s","J9s","JJ","JTo","JTs","K4s","K5s","K6s","K7s","K8s","K9s","KJo","KJs","KK","KQo","KQs","KTo","KTs","Q6s","Q7s","Q8s","Q9s","QJo","QJs","QQ","QTo","QTs","T8s","T9s","TT"],
    "mixed": {"K3s":{"raise":0.5,"fold":0.5},"J7s":{"raise":0.5,"fold":0.5},"T7s":{"raise":0.5,"fold":0.5},"A8o":{"raise":0.5,"fold":0.5},"22":{"raise":0.5,"fold":0.5}},
    "fold": ["32o","32s","42o","42s","43o","43s","52o","52s","53o","53s","54o","62o","62s","63o","63s","64o","64s","65o","72o","72s","73o","73s","74o","74s","75o","75s","76o","82o","82s","83o","83s","84o","84s","85o","85s","86o","86s","87o","92o","92s","93o","93s","94o","94s","95o","95s","96o","96s","97o","98o","A2o","A3o","A4o","A6o","A7o","J2o","J2s","J3o","J3s","J4o","J4s","J5o","J5s","J6o","J6s","J7o","J8o","J9o","K2o","K2s","K3o","K4o","K5o","K6o","K7o","K8o","K9o","Q2o","Q2s","Q3o","Q3s","Q4o","Q4s","Q5o","Q5s","Q6o","Q7o","Q8o","Q9o","T2o","T2s","T3o","T3s","T4o","T4s","T5o","T5s","T6o","T6s","T7o","T8o","T9o"]
  },
  "BTN": {
    "raise": ["22","33","44","54s","55","65s","66","75s","76s","77","86s","87s","88","96s","97s","98s","99","A2s","A3s","A4o","A4s","A5o","A5s","A6o","A6s","A7o","A7s","A8o","A8s","A9o","A9s","AA","AJo","AJs","AKo","AKs","AQo","AQs","ATo","ATs","J5s","J6s","J7s","J8s","J9o","J9s","JJ","JTo","JTs","K2s","K3s","K4s","K5s","K6s","K7s","K8s","K9o","K9s","KJo","KJs","KK","KQo","KQs","KTo","KTs","Q3s","Q4s","Q5s","Q6s","Q7s","Q8s","Q9o","Q9s","QJo","QJs","QQ","QTo","QTs","T6s","T7s","T8s","T9o","T9s","TT"],
    "mixed": {"J4s":{"raise":0.5,"fold":0.5},"K8o":{"raise":0.5,"fold":0.5},"J8o":{"raise":0.5,"fold":0.5},"T8o":{"raise":0.5,"fold":0.5},"98o":{"raise":0.5,"fold":0.5}},
    "fold": ["32o","32s","42o","42s","43o","43s","52o","52s","53o","53s","54o","62o","62s","63o","63s","64o","64s","65o","72o","72s","73o","73s","74o","74s","75o","76o","82o","82s","83o","83s","84o","84s","85o","85s","86o","87o","92o","92s","93o","93s","94o","94s","95o","95s","96o","97o","A2o","A3o","J2o","J2s","J3o","J3s","J4o","J5o","J6o","J7o","K2o","K3o","K4o","K5o","K6o","K7o","Q2o","Q2s","Q3o","Q4o","Q5o","Q6o","Q7o","Q8o","T2o","T2s","T3o","T3s","T4o","T4s","T5o","T5s","T6o","T7o"]
  },
  "SB": {
    "raise": ["22","33","44","54s","55","64s","65s","66","75s","76s","77","85s","86s","87s","88","96s","97s","98s","99","A2o","A2s","A3o","A3s","A4o","A4s","A5o","A5s","A6o","A6s","A7o","A7s","A8o","A8s","A9o","A9s","AA","AJo","AJs","AKo","AKs","AQo","AQs","ATo","ATs","J4s","J5s","J6s","J7s","J8o","J8s","J9o","J9s","JJ","JTo","JTs","K2s","K3s","K4s","K5s","K6s","K7s","K8o","K8s","K9o","K9s","KJo","KJs","KK","KQo","KQs","KTo","KTs","Q2s","Q3s","Q4s","Q5s","Q6s","Q7s","Q8o","Q8s","Q9o","Q9s","QJo","QJs","QQ","QTo","QTs","T6s","T7s","T8o","T8s","T9o","T9s","TT"],
    "mixed": {"K7o":{"raise":0.5,"fold":0.5},"Q7o":{"raise":0.5,"fold":0.5},"J7o":{"raise":0.5,"fold":0.5},"97o":{"raise":0.5,"fold":0.5},"87o":{"raise":0.5,"fold":0.5},"53s":{"raise":0.5,"fold":0.5},"43s":{"raise":0.5,"fold":0.5}},
    "fold": ["32o","32s","42o","42s","43o","52o","52s","53o","62o","62s","63o","63s","64o","65o","72o","72s","73o","73s","74o","74s","75o","76o","82o","82s","83o","83s","84o","84s","85o","86o","92o","92s","93o","93s","94o","94s","95o","95s","96o","J2o","J2s","J3o","J3s","J4o","J5o","J6o","K2o","K3o","K4o","K5o","K6o","Q2o","Q3o","Q4o","Q5o","Q6o","T2o","T2s","T3o","T3s","T4o","T4s","T5o","T6o","T7o"]
  }
};

export const RANKS = ['A', 'K', 'Q', 'J', 'T', '9', '8', '7', '6', '5', '4', '3', '2'] as const;
export const SUITS: Card['suit'][] = ['s', 'h', 'd', 'c'];

export const SUIT_SYMBOLS: Record<Card['suit'], string> = {
  s: '♠',
  h: '♥',
  d: '♦',
  c: '♣'
};

export const SUIT_NAMES: Record<Card['suit'], string> = {
  s: '黑桃',
  h: '红桃',
  d: '方块',
  c: '梅花'
};

// Return standard hand string given two cards (e.g. Card 1, Card 2 -> "AKs", "AKo", "AA")
export function getHandString(c1: Card, c2: Card): string {
  const r1Idx = RANKS.indexOf(c1.rank as any);
  const r2Idx = RANKS.indexOf(c2.rank as any);

  let highCard: Card, lowCard: Card;
  if (r1Idx <= r2Idx) {
    highCard = c1;
    lowCard = c2;
  } else {
    highCard = c2;
    lowCard = c1;
  }

  if (highCard.rank === lowCard.rank) {
    return `${highCard.rank}${lowCard.rank}`;
  }

  const suited = highCard.suit === lowCard.suit ? 's' : 'o';
  return `${highCard.rank}${lowCard.rank}${suited}`;
}

// Generate all 1326 distinct card pairs
export function getAll1326Combos(): Combo[] {
  const deck: Card[] = [];
  for (const r of RANKS) {
    for (const s of SUITS) {
      deck.push({ rank: r, suit: s });
    }
  }

  const combos: Combo[] = [];
  for (let i = 0; i < deck.length; i++) {
    for (let j = i + 1; j < deck.length; j++) {
      const c1 = deck[i];
      const c2 = deck[j];
      combos.push({
        card1: c1,
        card2: c2,
        handStr: getHandString(c1, c2)
      });
    }
  }
  return combos;
}

export function getHandActionType(position: Position, handStr: string): 'raise' | 'mixed' | 'fold' {
  const posData = RFI_STRATEGY[position];
  if (posData.raise.includes(handStr)) return 'raise';
  if (posData.mixed[handStr]) return 'mixed';
  return 'fold';
}

export interface DecisionResult {
  isCorrect: boolean;
  isMixed: boolean;
  evPenalty: number; // e.g. 0, -40, -60, -120
  message: string;
  recommendedAction: 'raise' | 'mixed' | 'fold';
  penaltyLevel: 'none' | 'minor' | 'medium' | 'blunder';
}

// Premier hands that trigger severe blunder penalty if folded
const PREMIER_RAISE_HANDS = ['AA', 'KK', 'QQ', 'JJ', 'AKs', 'AKo', 'AQs', 'AQo'];
// Total trash hands that trigger severe blunder penalty if raised
const TOTAL_TRASH_FOLDS = [
  '72o', '32o', '42o', '52o', '62o', '82o', '92o', 'T2o', 'J2o', 'Q2o', 'K2o',
  '73o', '83o', '93o', 'T3o', 'J3o', 'Q3o', 'K3o', '74o', '84o', '94o', 'T4o',
  '43o', '53o', '63o', '54o', '64o', '75o', '85o'
];

export function evaluateDecision(
  position: Position,
  handStr: string,
  userAction: 'raise' | 'fold'
): DecisionResult {
  const actionType = getHandActionType(position, handStr);

  // 1. Mixed Strategy Zone
  if (actionType === 'mixed') {
    return {
      isCorrect: true,
      isMixed: true,
      evPenalty: 0,
      message: '此手牌属于 50/50 混合策略区（加注/弃牌均可，0 EV 损失）',
      recommendedAction: 'mixed',
      penaltyLevel: 'none'
    };
  }

  // 2. Pure Strategy Correct
  if (actionType === userAction) {
    return {
      isCorrect: true,
      isMixed: false,
      evPenalty: 0,
      message: actionType === 'raise' ? '正确！该手牌在 GTO 中为 100% 加注' : '正确！该手牌在 GTO 中为 100% 弃牌',
      recommendedAction: actionType,
      penaltyLevel: 'none'
    };
  }

  // 3. Incorrect Choice - Calculate EV Penalty
  // Case A: Hand is Pure Raise, but User Folded
  if (actionType === 'raise' && userAction === 'fold') {
    if (PREMIER_RAISE_HANDS.includes(handStr)) {
      return {
        isCorrect: false,
        isMixed: false,
        evPenalty: -120,
        message: `重大爆破级失误！弃掉强牌 ${handStr} 造成极高 EV 亏损`,
        recommendedAction: 'raise',
        penaltyLevel: 'blunder'
      };
    }
    // Check if medium or minor
    const isMediumHand = ['TT', '99', '88', 'AJs', 'ATs', 'KQs', 'KJs', 'QJs', 'JTs'].includes(handStr);
    if (isMediumHand) {
      return {
        isCorrect: false,
        isMixed: false,
        evPenalty: -60,
        message: `中等失误：${handStr} 在 ${position} 应坚决加注`,
        recommendedAction: 'raise',
        penaltyLevel: 'medium'
      };
    }
    return {
      isCorrect: false,
      isMixed: false,
      evPenalty: -40,
      message: `边际轻微失误：${handStr} 处于 ${position} 加注边缘`,
      recommendedAction: 'raise',
      penaltyLevel: 'minor'
    };
  }

  // Case B: Hand is Pure Fold, but User Raised
  if (actionType === 'fold' && userAction === 'raise') {
    if (TOTAL_TRASH_FOLDS.includes(handStr)) {
      return {
        isCorrect: false,
        isMixed: false,
        evPenalty: -120,
        message: `重大爆破级失误！加注极弱牌 ${handStr} 属于无意义送钱`,
        recommendedAction: 'fold',
        penaltyLevel: 'blunder'
      };
    }
    // Check if close fold vs medium fold
    const isCloseFold = [
      '55', '22', '33', '44', 'A8o', 'A9o', 'K3s', 'K5s', 'Q8s', 'J7s', 'T7s', 'J9s', 'QTo', 'JTo', 'K8s'
    ].includes(handStr);

    if (isCloseFold) {
      return {
        isCorrect: false,
        isMixed: false,
        evPenalty: -40,
        message: `边际轻微失误：${handStr} 在 ${position} 略微偏向弃牌`,
        recommendedAction: 'fold',
        penaltyLevel: 'minor'
      };
    }

    return {
      isCorrect: false,
      isMixed: false,
      evPenalty: -60,
      message: `中等失误：${handStr} 在 ${position} 不符合首开加注要求`,
      recommendedAction: 'fold',
      penaltyLevel: 'medium'
    };
  }

  return {
    isCorrect: false,
    isMixed: false,
    evPenalty: -40,
    message: '决策错误',
    recommendedAction: actionType,
    penaltyLevel: 'minor'
  };
}
