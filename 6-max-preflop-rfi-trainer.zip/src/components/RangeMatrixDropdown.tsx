import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Position, RFI_STRATEGY, RANKS } from '../data/rfiStrategy';
import { Grid, ChevronDown, ChevronUp, X, Sparkles, Check } from 'lucide-react';

interface RangeMatrixDropdownProps {
  currentTrainingPosition: Position;
  currentHandStr: string | null;
}

const POSITIONS: { pos: Position; label: string; frequency: string }[] = [
  { pos: 'UTG', label: 'UTG 枪口', frequency: '16.8%' },
  { pos: 'MP', label: 'MP 中间', frequency: '20.1%' },
  { pos: 'CO', label: 'CO 关口', frequency: '27.2%' },
  { pos: 'BTN', label: 'BTN 庄家', frequency: '43.8%' },
  { pos: 'SB', label: 'SB 小盲', frequency: '48.5%' },
];

export const RangeMatrixDropdown: React.FC<RangeMatrixDropdownProps> = ({
  currentTrainingPosition,
  currentHandStr,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [queryPosition, setQueryPosition] = useState<Position>(currentTrainingPosition);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Sync selected query position with training position when training position changes
  useEffect(() => {
    setQueryPosition(currentTrainingPosition);
  }, [currentTrainingPosition]);

  // Close dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isOpen]);

  const posData = RFI_STRATEGY[queryPosition];

  // Calculate combo statistics
  const getHandComboCount = (handStr: string): number => {
    if (handStr.length === 2) return 6; // Pair
    if (handStr.endsWith('s')) return 4; // Suited
    return 12; // Offsuit
  };

  let totalRaiseCombos = 0;
  let totalMixedCombos = 0;

  posData.raise.forEach((h) => {
    totalRaiseCombos += getHandComboCount(h);
  });
  Object.keys(posData.mixed).forEach((h) => {
    totalMixedCombos += getHandComboCount(h) * 0.5;
  });

  const totalEffectiveCombos = totalRaiseCombos + totalMixedCombos;
  const frequencyPercent = ((totalEffectiveCombos / 1326) * 100).toFixed(1);

  return (
    <div className="relative inline-block text-left" ref={dropdownRef}>
      {/* Dropdown Trigger Button */}
      <button
        type="button"
        onClick={() => setIsOpen((prev) => !prev)}
        className={`flex items-center gap-2 px-3 py-1.5 rounded-lg border text-xs font-bold transition-all shadow-sm cursor-pointer ${
          isOpen
            ? 'bg-blue-600 text-white border-blue-400 ring-2 ring-blue-500/30'
            : 'bg-slate-800/90 hover:bg-slate-700 text-slate-200 border-slate-700/80 hover:border-blue-500/50'
        }`}
      >
        <Grid className={`w-4 h-4 ${isOpen ? 'text-white' : 'text-blue-400'}`} />
        <span>查询 GTO 矩阵</span>
        <span className="px-1.5 py-0.2 bg-blue-500/20 text-blue-300 font-mono text-[10px] rounded border border-blue-500/30">
          {queryPosition} ({frequencyPercent}%)
        </span>
        {isOpen ? (
          <ChevronUp className="w-3.5 h-3.5 text-blue-200" />
        ) : (
          <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
        )}
      </button>

      {/* Dropdown Menu Popover Panel */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: -10, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -10, scale: 0.98 }}
            transition={{ duration: 0.15 }}
            className="absolute left-0 sm:right-0 sm:left-auto mt-2 w-[340px] sm:w-[480px] bg-[#1E293B] border border-slate-700 rounded-2xl shadow-2xl p-4 z-50 text-slate-100"
          >
            {/* Popover Header */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-700/80">
              <div className="flex items-center gap-2">
                <div className="p-1.5 rounded bg-blue-500/10 text-blue-400 border border-blue-500/20">
                  <Sparkles className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white flex items-center gap-1.5">
                    GTO 翻前范围查询矩阵
                  </h4>
                  <p className="text-[11px] text-slate-400">
                    随时切换位置查阅 13x13 矩阵，辅助练习与判别
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setIsOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Position Switcher Tabs inside Dropdown */}
            <div className="my-3 flex items-center gap-1 bg-slate-900/90 p-1 rounded-xl border border-slate-800">
              {POSITIONS.map(({ pos, label, frequency }) => {
                const isActive = queryPosition === pos;
                const isCurrentTraining = currentTrainingPosition === pos;
                return (
                  <button
                    key={pos}
                    type="button"
                    onClick={() => setQueryPosition(pos)}
                    className={`flex-1 py-1.5 px-1 rounded-lg text-xs font-bold transition-all flex flex-col items-center justify-center cursor-pointer ${
                      isActive
                        ? 'bg-blue-600 text-white shadow-md'
                        : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                    }`}
                  >
                    <span className="flex items-center gap-1">
                      {pos}
                      {isCurrentTraining && (
                        <span
                          className="w-1.5 h-1.5 rounded-full bg-emerald-400"
                          title="当前练习位置"
                        />
                      )}
                    </span>
                    <span className="text-[9px] font-mono opacity-80">{frequency}</span>
                  </button>
                );
              })}
            </div>

            {/* Stats Bar & Legend */}
            <div className="flex flex-wrap items-center justify-between gap-2 mb-3 text-xs bg-slate-900/50 p-2 rounded-lg border border-slate-800">
              <span className="text-slate-300 font-mono text-[11px]">
                {queryPosition} RFI 频率: <strong className="text-emerald-400">{frequencyPercent}%</strong> ({totalRaiseCombos} 纯加注 / {Object.keys(posData.mixed).length} 混合)
              </span>

              {/* Legend */}
              <div className="flex items-center gap-2 text-[10px]">
                <div className="flex items-center gap-1">
                  <div className="w-2.5 h-2.5 rounded bg-emerald-500" />
                  <span className="text-slate-300">Raise</span>
                </div>
                <div className="flex items-center gap-1">
                  <div className="w-2.5 h-2.5 rounded bg-amber-500" />
                  <span className="text-slate-300">Mixed</span>
                </div>
                <div className="flex items-center gap-1">
                  <div className="w-2.5 h-2.5 rounded bg-slate-800 border border-slate-700" />
                  <span className="text-slate-400">Fold</span>
                </div>
              </div>
            </div>

            {/* 13x13 Grid */}
            <div className="grid grid-cols-13 gap-0.5 sm:gap-1 w-full max-w-sm sm:max-w-md mx-auto aspect-square">
              {RANKS.map((r1, i) =>
                RANKS.map((r2, j) => {
                  let handStr = '';
                  if (i === j) {
                    handStr = `${r1}${r2}`;
                  } else if (i < j) {
                    handStr = `${r1}${r2}s`;
                  } else {
                    handStr = `${r2}${r1}o`;
                  }

                  const isRaise = posData.raise.includes(handStr);
                  const isMixed = posData.mixed[handStr] !== undefined;
                  const isCurrentHand = queryPosition === currentTrainingPosition && currentHandStr === handStr;

                  return (
                    <div
                      key={handStr}
                      title={`${handStr} (${isRaise ? '100% Raise' : isMixed ? '50/50 Mixed' : '100% Fold'})`}
                      className={`relative aspect-square flex items-center justify-center text-[8px] sm:text-[10px] font-mono font-bold rounded select-none transition-all ${
                        isRaise
                          ? 'bg-emerald-600 text-white shadow-sm'
                          : isMixed
                          ? 'bg-gradient-to-br from-emerald-600 to-amber-500 text-white'
                          : 'bg-slate-900 text-slate-500 border border-slate-800/80'
                      } ${
                        isCurrentHand
                          ? 'ring-2 ring-amber-400 ring-offset-1 ring-offset-slate-900 z-10 scale-110 font-black shadow-lg shadow-amber-500/40'
                          : ''
                      }`}
                    >
                      {handStr}
                    </div>
                  );
                })
              )}
            </div>

            <div className="mt-3 text-center text-[10px] text-slate-400 font-mono">
              提示：高亮外框为当前牌桌发出的手牌 ({currentHandStr || 'N/A'})
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
