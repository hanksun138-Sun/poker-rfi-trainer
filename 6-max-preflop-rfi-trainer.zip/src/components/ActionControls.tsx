import React from 'react';
import { ArrowUpRight, Ban, ArrowRight, CornerDownLeft } from 'lucide-react';

interface ActionControlsProps {
  isAnswered: boolean;
  onAction: (action: 'raise' | 'fold') => void;
  onNext: () => void;
}

export const ActionControls: React.FC<ActionControlsProps> = ({
  isAnswered,
  onAction,
  onNext,
}) => {
  return (
    <div className="w-full max-w-lg mx-auto flex flex-col gap-3">
      {!isAnswered ? (
        <div className="grid grid-cols-2 gap-4">
          {/* Fold Button */}
          <button
            onClick={() => onAction('fold')}
            className="group relative flex flex-col items-center justify-center py-4 px-6 bg-slate-800 hover:bg-slate-700 active:scale-[0.98] border border-slate-700/80 rounded-2xl shadow-xl transition-all cursor-pointer"
          >
            <div className="flex items-center gap-2 text-slate-100 font-extrabold text-lg sm:text-xl">
              <Ban className="w-5 h-5 text-slate-400 group-hover:text-white transition-colors" />
              <span>Fold 弃牌</span>
            </div>
            <div className="flex items-center gap-1 text-[11px] text-slate-400 mt-1 font-mono">
              <span>快捷键:</span>
              <kbd className="px-1.5 py-0.5 bg-slate-900 text-slate-300 rounded border border-slate-700 text-[10px]">
                F
              </kbd>
              <span>或</span>
              <kbd className="px-1.5 py-0.5 bg-slate-900 text-slate-300 rounded border border-slate-700 text-[10px]">
                ←
              </kbd>
            </div>
          </button>

          {/* Raise Button */}
          <button
            onClick={() => onAction('raise')}
            className="group relative flex flex-col items-center justify-center py-4 px-6 bg-gradient-to-b from-emerald-600 to-emerald-700 hover:from-emerald-500 hover:to-emerald-600 active:scale-[0.98] border border-emerald-400/40 rounded-2xl shadow-xl shadow-emerald-950/50 transition-all cursor-pointer"
          >
            <div className="flex items-center gap-2 text-white font-black text-lg sm:text-xl tracking-tight">
              <ArrowUpRight className="w-6 h-6 text-emerald-200 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
              <span>Raise 2.5bb</span>
            </div>
            <div className="flex items-center gap-1 text-[11px] text-emerald-100/80 mt-1 font-mono">
              <span>快捷键:</span>
              <kbd className="px-1.5 py-0.5 bg-emerald-900/80 text-emerald-100 rounded border border-emerald-500/40 text-[10px]">
                R
              </kbd>
              <span>或</span>
              <kbd className="px-1.5 py-0.5 bg-emerald-900/80 text-emerald-100 rounded border border-emerald-500/40 text-[10px]">
                →
              </kbd>
            </div>
          </button>
        </div>
      ) : (
        /* Next Hand Button */
        <button
          onClick={onNext}
          className="w-full py-4 px-6 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 active:scale-[0.99] text-white font-extrabold text-lg rounded-2xl shadow-xl shadow-blue-950/60 border border-blue-400/30 flex items-center justify-center gap-2 transition-all cursor-pointer animate-pulse"
        >
          <span>下一手牌</span>
          <ArrowRight className="w-5 h-5" />
          <span className="text-xs font-normal text-blue-200/80 font-mono ml-2">
            [空格键 Space]
          </span>
        </button>
      )}
    </div>
  );
};
