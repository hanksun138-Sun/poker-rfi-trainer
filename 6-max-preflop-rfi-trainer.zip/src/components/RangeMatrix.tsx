import React, { useState } from 'react';
import { Position, RFI_STRATEGY, RANKS } from '../data/rfiStrategy';
import { Eye, EyeOff, Grid, ChevronDown, ChevronUp } from 'lucide-react';

interface RangeMatrixProps {
  position: Position;
  currentHandStr: string | null;
  defaultExpanded?: boolean;
}

export const RangeMatrix: React.FC<RangeMatrixProps> = ({
  position,
  currentHandStr,
  defaultExpanded = false,
}) => {
  const [isExpanded, setIsExpanded] = useState(defaultExpanded);

  const posData = RFI_STRATEGY[position];

  // Calculate combo statistics
  const getHandComboCount = (handStr: string): number => {
    if (handStr.length === 2) return 6; // Pair
    if (handStr.endsWith('s')) return 4; // Suited
    return 12; // Offsuit
  };

  let totalRaiseCombos = 0;
  let totalMixedCombos = 0;

  posData.raise.forEach((h) => {
    totalRaiseCombos += getHandComboCount(h);
  });
  Object.keys(posData.mixed).forEach((h) => {
    totalMixedCombos += getHandComboCount(h) * 0.5; // 50%
  });

  const totalEffectiveCombos = totalRaiseCombos + totalMixedCombos;
  const frequencyPercent = ((totalEffectiveCombos / 1326) * 100).toFixed(1);

  return (
    <div className="w-full bg-[#1E293B] border border-slate-700/80 rounded-xl p-3.5 shadow-lg transition-all duration-300">
      {/* Header Bar (Clickable trigger) */}
      <div
        onClick={() => setIsExpanded(!isExpanded)}
        className="flex items-center justify-between cursor-pointer select-none group"
      >
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded-lg bg-blue-500/10 text-blue-400 group-hover:bg-blue-500/20 transition-colors border border-blue-500/20">
            <Grid className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs sm:text-sm font-bold text-slate-100 group-hover:text-blue-400 transition-colors">
                {position} RFI 范围图表 (13x13 矩阵)
              </span>
              <span className="px-1.5 py-0.5 bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 rounded text-[10px] font-mono font-bold">
                {frequencyPercent}% RFI
              </span>
            </div>
            <p className="text-[11px] text-slate-400 mt-0.5">
              {isExpanded ? '图表已展开 · 点击收起可防练习剧透' : '图表默认已隐藏 · 点击展开查看完整 GTO 范围图表'}
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            setIsExpanded(!isExpanded);
          }}
          className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg border transition-all shadow-sm ${
            isExpanded
              ? 'bg-slate-800 hover:bg-slate-700 text-slate-300 border-slate-600/80'
              : 'bg-blue-600 hover:bg-blue-500 text-white border-blue-500 hover:shadow-blue-500/20'
          }`}
        >
          {isExpanded ? (
            <>
              <EyeOff className="w-3.5 h-3.5 text-slate-400" />
              <span>收起图表</span>
              <ChevronUp className="w-3.5 h-3.5 text-slate-400" />
            </>
          ) : (
            <>
              <Eye className="w-3.5 h-3.5 text-blue-100" />
              <span>点击查看范围</span>
              <ChevronDown className="w-3.5 h-3.5 text-blue-200" />
            </>
          )}
        </button>
      </div>

      {/* Expandable 13x13 Matrix Body */}
      {isExpanded && (
        <div className="mt-3.5 pt-3 border-t border-slate-700/80 animate-fadeIn">
          {/* Subheader Info & Legend */}
          <div className="flex flex-wrap items-center justify-between gap-2 mb-3 text-xs">
            <span className="text-slate-400 text-[11px] font-mono">
              纯加注: {totalRaiseCombos} 组合 | 混合: {Object.keys(posData.mixed).length} 起手牌
            </span>

            {/* Legend */}
            <div className="flex items-center gap-2.5 text-[11px]">
              <div className="flex items-center gap-1">
                <div className="w-2.5 h-2.5 rounded bg-emerald-500" />
                <span className="text-slate-300">100% Raise</span>
              </div>
              <div className="flex items-center gap-1">
                <div className="w-2.5 h-2.5 rounded bg-amber-500" />
                <span className="text-slate-300">50/50 Mixed</span>
              </div>
              <div className="flex items-center gap-1">
                <div className="w-2.5 h-2.5 rounded bg-slate-800 border border-slate-700" />
                <span className="text-slate-400">Fold</span>
              </div>
            </div>
          </div>

          {/* 13x13 Grid Container */}
          <div className="grid grid-cols-13 gap-1 w-full max-w-md sm:max-w-lg mx-auto aspect-square">
            {RANKS.map((r1, i) =>
              RANKS.map((r2, j) => {
                let handStr = '';
                if (i === j) {
                  handStr = `${r1}${r2}`;
                } else if (i < j) {
                  handStr = `${r1}${r2}s`;
                } else {
                  handStr = `${r2}${r1}o`;
                }

                const isRaise = posData.raise.includes(handStr);
                const isMixed = posData.mixed[handStr] !== undefined;
                const isCurrent = currentHandStr === handStr;

                return (
                  <div
                    key={handStr}
                    title={`${handStr} (${isRaise ? '100% Raise' : isMixed ? '50/50 Mixed' : '100% Fold'})`}
                    className={`relative aspect-square flex items-center justify-center text-[9px] sm:text-[10px] font-mono font-bold rounded select-none transition-all ${
                      isRaise
                        ? 'bg-emerald-600 text-white shadow-sm'
                        : isMixed
                        ? 'bg-gradient-to-br from-emerald-600 to-amber-500 text-white'
                        : 'bg-slate-800/90 text-slate-500 border border-slate-800/80'
                    } ${
                      isCurrent
                        ? 'ring-2 ring-amber-400 ring-offset-1 ring-offset-slate-900 z-10 scale-110 font-black shadow-lg shadow-amber-500/30'
                        : ''
                    }`}
                  >
                    {handStr}
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}
    </div>
  );
};

