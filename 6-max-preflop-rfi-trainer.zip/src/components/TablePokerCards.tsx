import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Combo, Card as CardType, Position, SUIT_SYMBOLS } from '../data/rfiStrategy';
import { DeckSuitStyle } from '../types';
import { Palette, AlertTriangle } from 'lucide-react';

interface TablePokerCardsProps {
  combo: Combo | null;
  position: Position;
  isFromQueue: boolean;
  deckStyle: DeckSuitStyle;
  onToggleDeckStyle: () => void;
  onSelectPosition?: (pos: Position) => void;
}

export const TablePokerCards: React.FC<TablePokerCardsProps> = ({
  combo,
  position,
  isFromQueue,
  deckStyle,
  onToggleDeckStyle,
  onSelectPosition,
}) => {
  if (!combo) return null;

  const getSuitColorClass = (suit: CardType['suit']) => {
    if (deckStyle === '4color') {
      switch (suit) {
        case 's': return 'text-slate-950'; // Black spades
        case 'h': return 'text-red-600';  // Red hearts
        case 'd': return 'text-blue-600'; // Blue diamonds
        case 'c': return 'text-emerald-600'; // Green clubs
      }
    } else {
      return suit === 'h' || suit === 'd' ? 'text-red-600' : 'text-slate-950';
    }
  };

  // Seat order around a standard 6-Max table
  const seats: { id: Position | 'BB'; label: string; name: string }[] = [
    { id: 'UTG', label: 'UTG', name: '枪口位' },
    { id: 'MP', label: 'HJ', name: '中间位' },
    { id: 'CO', label: 'CO', name: '关口位' },
    { id: 'BTN', label: 'BTN', name: '庄家位' },
    { id: 'SB', label: 'SB', name: '小盲位' },
    { id: 'BB', label: 'BB', name: '大盲位' },
  ];

  // Determine status for each seat based on current Hero position
  const getSeatStatus = (seatId: Position | 'BB') => {
    if (seatId === position) {
      return { isHero: true, text: '已决策', statusColor: 'bg-emerald-500 text-slate-950 font-bold' };
    }

    const order: (Position | 'BB')[] = ['UTG', 'MP', 'CO', 'BTN', 'SB', 'BB'];
    const heroIndex = order.indexOf(position);
    const seatIndex = order.indexOf(seatId);

    if (seatIndex < heroIndex) {
      // Acted before hero -> Folded
      return { isHero: false, text: '弃牌 Fold', statusColor: 'bg-rose-950/80 text-rose-400 border border-rose-800/40' };
    } else if (seatId === 'BB') {
      return { isHero: false, text: '大盲 1.0 BB', statusColor: 'bg-slate-900/90 text-slate-300' };
    } else if (seatId === 'SB') {
      return { isHero: false, text: '小盲 0.5 BB', statusColor: 'bg-slate-900/90 text-slate-300' };
    } else {
      return { isHero: false, text: '等待中', statusColor: 'bg-slate-900/80 text-slate-400' };
    }
  };

  return (
    <div className="w-full relative bg-[#0B132B] border border-slate-700/80 rounded-2xl p-4 sm:p-6 shadow-2xl overflow-hidden flex flex-col items-center">
      {/* Top Bar Controls */}
      <div className="w-full flex items-center justify-between z-10 mb-2">
        <div className="flex items-center gap-2">
          <span className="px-2.5 py-0.5 bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 font-mono text-xs font-bold rounded-full">
            6-Max 翻前 RFI
          </span>
          {isFromQueue && (
            <span className="flex items-center gap-1 px-2.5 py-0.5 bg-amber-500/20 border border-amber-500/40 text-amber-300 text-xs font-bold rounded-full">
              <AlertTriangle className="w-3 h-3 text-amber-400" />
              错题重练
            </span>
          )}
        </div>

        <button
          onClick={onToggleDeckStyle}
          className="flex items-center gap-1 px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium rounded-lg border border-slate-700 transition-all cursor-pointer"
        >
          <Palette className="w-3.5 h-3.5 text-emerald-400" />
          <span>{deckStyle === '4color' ? '4色牌面' : '2色牌面'}</span>
        </button>
      </div>

      {/* Realistic 6-Max Oval Poker Table Felt */}
      <div className="w-full max-w-4xl sm:max-w-5xl relative bg-[#0B6637] border-[8px] sm:border-[12px] border-[#8B5E34] rounded-[90px] sm:rounded-[140px] p-4 sm:p-8 shadow-[inset_0_0_60px_rgba(0,0,0,0.6)] flex flex-col items-center justify-center min-h-[260px] sm:min-h-[330px] my-1 sm:my-2">
        {/* Inner Gold Stitched Ring line */}
        <div className="absolute inset-3 sm:inset-4 border-2 border-amber-500/30 rounded-[85px] sm:rounded-[120px] pointer-events-none" />

        {/* Table Center Info */}
        <div className="flex flex-col items-center justify-center gap-1 mb-2 z-10">
          <div className="px-4 py-1 bg-black/60 border border-amber-500/60 rounded-full text-amber-300 font-mono text-xs sm:text-sm font-bold shadow-lg flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
            <span>底池 (POT): <strong className="text-amber-400">1.5 BB</strong></span>
          </div>
          <p className="text-[11px] sm:text-xs text-emerald-100/80 font-medium italic">
            Preflop 翻前开局首开阶段...
          </p>
        </div>

        {/* 6 Seats Layout Grid around Oval */}
        {/* Top Seats: UTG (Top Left), MP/HJ (Top Right) */}
        <div className="w-full flex items-center justify-between px-2 sm:px-12 absolute top-3 sm:top-5">
          {/* UTG */}
          {renderSeat('UTG', 'UTG 枪口', position, getSeatStatus('UTG'), onSelectPosition)}
          {/* MP / HJ */}
          {renderSeat('MP', 'HJ 中间', position, getSeatStatus('MP'), onSelectPosition)}
        </div>

        {/* Middle Side Seats: BB (Left), CO (Right) */}
        <div className="w-full flex items-center justify-between px-1 sm:px-4 absolute top-1/2 -translate-y-1/2">
          {/* BB */}
          {renderSeat('BB', 'BB 大盲', position, getSeatStatus('BB'), undefined)}
          {/* CO */}
          {renderSeat('CO', 'CO 关口', position, getSeatStatus('CO'), onSelectPosition)}
        </div>

        {/* Bottom Seats: SB (Bottom Left), BTN (Bottom Right) */}
        <div className="w-full flex items-center justify-between px-2 sm:px-12 absolute bottom-3 sm:bottom-5">
          {/* SB */}
          {renderSeat('SB', 'SB 小盲', position, getSeatStatus('SB'), onSelectPosition)}
          {/* BTN */}
          {renderSeat('BTN', 'BTN 庄家', position, getSeatStatus('BTN'), onSelectPosition)}
        </div>

        {/* Center Playing Cards Display for Hero */}
        <div className="z-20 my-auto py-2">
          <AnimatePresence mode="wait">
            <motion.div
              key={`${position}-${combo.handStr}-${combo.card1.suit}${combo.card1.rank}-${combo.card2.suit}${combo.card2.rank}`}
              initial={{ scale: 0.8, y: 15, opacity: 0 }}
              animate={{ scale: 1, y: 0, opacity: 1 }}
              exit={{ scale: 0.8, y: -15, opacity: 0 }}
              transition={{ type: 'spring', stiffness: 350, damping: 28 }}
              className="flex items-center justify-center gap-3 sm:gap-5"
            >
              {[combo.card1, combo.card2].map((card, idx) => {
                const suitColor = getSuitColorClass(card.suit);
                return (
                  <motion.div
                    key={idx}
                    whileHover={{ y: -6, rotate: idx === 0 ? -2 : 2 }}
                    className="w-20 h-28 sm:w-28 sm:h-40 bg-gradient-to-b from-white via-slate-50 to-slate-100 rounded-xl p-2 sm:p-3 flex flex-col justify-between shadow-2xl shadow-black/80 border border-slate-300 relative select-none"
                  >
                    {/* Top Left Rank & Suit */}
                    <div className={`flex flex-col items-start leading-none ${suitColor}`}>
                      <span className="text-base sm:text-2xl font-black">{card.rank}</span>
                      <span className="text-xs sm:text-base font-bold mt-0.5">
                        {SUIT_SYMBOLS[card.suit]}
                      </span>
                    </div>

                    {/* Center Big Symbol */}
                    <div className={`self-center text-2xl sm:text-4xl font-black ${suitColor}`}>
                      {SUIT_SYMBOLS[card.suit]}
                    </div>

                    {/* Bottom Right Inverted Rank & Suit */}
                    <div className={`flex flex-col items-end leading-none rotate-180 ${suitColor}`}>
                      <span className="text-base sm:text-2xl font-black">{card.rank}</span>
                      <span className="text-xs sm:text-base font-bold mt-0.5">
                        {SUIT_SYMBOLS[card.suit]}
                      </span>
                    </div>
                  </motion.div>
                );
              })}
            </motion.div>
          </AnimatePresence>
        </div>
      </div>

      {/* Hand Name Footer */}
      <div className="flex items-center gap-2 mt-1 px-4 py-1 bg-slate-800/90 border border-slate-700/80 rounded-lg text-xs font-mono">
        <span className="text-slate-400">Current Hole Cards 当前手牌:</span>
        <span className="font-bold text-amber-400 text-sm">{combo.handStr}</span>
      </div>
    </div>
  );
};

function renderSeat(
  seatId: Position | 'BB',
  displayName: string,
  currentHeroPos: Position,
  status: { isHero: boolean; text: string; statusColor: string },
  onSelectPosition?: (pos: Position) => void
) {
  const isHero = seatId === currentHeroPos;

  return (
    <div
      onClick={() => {
        if (seatId !== 'BB' && onSelectPosition) {
          onSelectPosition(seatId as Position);
        }
      }}
      className={`flex flex-col items-center gap-1 cursor-pointer transition-transform ${
        isHero ? 'scale-105 z-30' : 'hover:scale-102 opacity-90'
      }`}
    >
      <div
        className={`px-2.5 py-1 rounded-lg flex flex-col items-center border shadow-md text-[10px] sm:text-xs min-w-[70px] sm:min-w-[85px] ${
          isHero
            ? 'bg-amber-500 text-slate-950 font-extrabold border-amber-300 ring-2 ring-amber-400/50'
            : seatId === 'BB'
            ? 'bg-rose-950/90 text-rose-300 border-rose-800/50'
            : 'bg-slate-900/90 text-slate-200 border-slate-700'
        }`}
      >
        <div className="flex items-center gap-1 font-mono font-bold">
          <span>{seatId}</span>
          <span className="text-[9px] opacity-80">(100 BB)</span>
        </div>
        <span className="text-[9px] font-sans font-normal opacity-90">{displayName}</span>
      </div>

      {/* Action status pill below seat */}
      <span className={`px-2 py-0.5 rounded text-[9px] font-mono shadow ${status.statusColor}`}>
        {status.text}
      </span>
    </div>
  );
}
