import React from 'react';
import { Download, RotateCcw, ShieldCheck, Layers } from 'lucide-react';
import { TrainingStats } from '../types';

interface HeaderProps {
  stats: TrainingStats;
  onResetStats: () => void;
  onOpenMistakeQueue: () => void;
  mistakeCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  stats,
  onResetStats,
  onOpenMistakeQueue,
  mistakeCount,
}) => {
  const accuracy = stats.totalHands > 0 ? ((stats.correctCount / stats.totalHands) * 100).toFixed(1) : '100.0';

  const handleDownloadSingleFileHtml = () => {
    fetch('/1_Preflop_RFI.html')
      .then((res) => res.text())
      .then((htmlContent) => {
        const blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = '1_Preflop_RFI.html';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
      })
      .catch(() => {
        alert('无法加载 1_Preflop_RFI.html 单文件');
      });
  };

  return (
    <header className="w-full bg-[#1E293B] border-b border-slate-700/80 px-4 sm:px-6 py-2.5 shadow-xl flex flex-col md:flex-row items-center justify-between gap-3">
      {/* Brand & Stats */}
      <div className="flex flex-wrap items-center gap-4 sm:gap-6">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
            <ShieldCheck className="w-4 h-4" />
          </div>
          <h1 className="text-base font-bold tracking-tight text-emerald-400 flex items-center gap-2">
            GTO RFI TRAINER
            <span className="text-[11px] font-mono font-normal text-slate-400">v2.1.0 (100bb)</span>
          </h1>
        </div>

        {/* High Density Metric Counter Bar */}
        <div className="flex items-center gap-4 border-l border-slate-700/80 pl-4 sm:pl-6 text-xs">
          <div className="flex flex-col">
            <span className="text-[9px] font-semibold uppercase tracking-wider text-slate-400">Accuracy 准确率</span>
            <span className={`text-sm font-mono font-bold tabular-nums ${Number(accuracy) >= 90 ? 'text-emerald-400' : 'text-amber-400'}`}>
              {accuracy}%
            </span>
          </div>

          <div className="flex flex-col">
            <span className="text-[9px] font-semibold uppercase tracking-wider text-slate-400">EV Loss 累计亏损</span>
            <span className={`text-sm font-mono font-bold tabular-nums ${stats.totalEVLoss === 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
              -{stats.totalEVLoss} mBB
            </span>
          </div>

          <div className="flex flex-col">
            <span className="text-[9px] font-semibold uppercase tracking-wider text-slate-400">Hands 手数</span>
            <span className="text-sm font-mono font-bold text-blue-400 tabular-nums">
              {stats.totalHands}
            </span>
          </div>

          {stats.currentStreak > 0 && (
            <div className="hidden sm:flex flex-col">
              <span className="text-[9px] font-semibold uppercase tracking-wider text-slate-400">Streak 连对</span>
              <span className="text-sm font-mono font-bold text-amber-400 tabular-nums">
                {stats.currentStreak}
              </span>
            </div>
          )}
        </div>
      </div>

      {/* Top Controls */}
      <div className="flex items-center gap-2 self-end md:self-auto">
        <button
          onClick={onOpenMistakeQueue}
          className="relative px-2.5 py-1 text-xs font-semibold bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 rounded flex items-center gap-1.5 transition-all cursor-pointer"
          title="查看漏水错题库"
        >
          <Layers className="w-3.5 h-3.5 text-amber-400" />
          <span>错题库</span>
          {mistakeCount > 0 && (
            <span className="px-1.5 py-0.2 bg-amber-500 text-slate-950 font-bold text-[10px] rounded-full">
              {mistakeCount}
            </span>
          )}
        </button>

        <button
          onClick={handleDownloadSingleFileHtml}
          className="px-2.5 py-1 text-xs font-semibold bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 rounded flex items-center gap-1.5 transition-all cursor-pointer"
          title="导出单文件 1_Preflop_RFI.html"
        >
          <Download className="w-3.5 h-3.5" />
          <span>下载 1_Preflop_RFI.html</span>
        </button>

        <button
          onClick={onResetStats}
          className="px-2.5 py-1 text-xs font-semibold bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/30 rounded flex items-center gap-1 transition-all cursor-pointer"
          title="重置统计"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>重置</span>
        </button>
      </div>
    </header>
  );
};

