import React from 'react';
import { TrainingStats } from '../types';
import { Target, TrendingDown, Flame, Layers, Percent } from 'lucide-react';

interface StatsBarProps {
  stats: TrainingStats;
  mistakeCount: number;
}

export const StatsBar: React.FC<StatsBarProps> = ({ stats, mistakeCount }) => {
  const accuracy = stats.totalHands > 0 ? Math.round((stats.correctCount / stats.totalHands) * 100) : 100;

  return (
    <div className="w-full max-w-5xl mx-auto grid grid-cols-2 sm:grid-cols-4 gap-3">
      {/* Total Hands */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-3 flex items-center justify-between shadow-md">
        <div>
          <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
            训练手数
          </span>
          <span className="text-xl font-bold text-white mt-0.5 block">{stats.totalHands}</span>
        </div>
        <div className="w-9 h-9 rounded-lg bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-blue-400">
          <Target className="w-4 h-4" />
        </div>
      </div>

      {/* Accuracy */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-3 flex items-center justify-between shadow-md">
        <div>
          <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
            正确率
          </span>
          <span className={`text-xl font-bold mt-0.5 block ${accuracy >= 90 ? 'text-emerald-400' : accuracy >= 75 ? 'text-amber-400' : 'text-rose-400'}`}>
            {accuracy}%
          </span>
        </div>
        <div className="w-9 h-9 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
          <Percent className="w-4 h-4" />
        </div>
      </div>

      {/* EV Loss */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-3 flex items-center justify-between shadow-md">
        <div>
          <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
            累计 EV 损失
          </span>
          <span className={`text-xl font-bold mt-0.5 block ${stats.totalEVLoss === 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
            -{stats.totalEVLoss} <span className="text-xs font-normal text-slate-400">mBB</span>
          </span>
        </div>
        <div className="w-9 h-9 rounded-lg bg-rose-500/10 border border-rose-500/20 flex items-center justify-center text-rose-400">
          <TrendingDown className="w-4 h-4" />
        </div>
      </div>

      {/* Streak & Mistake Queue */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-3 flex items-center justify-between shadow-md">
        <div>
          <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
            错题库 (锁定)
          </span>
          <div className="flex items-baseline gap-2 mt-0.5">
            <span className={`text-xl font-bold ${mistakeCount > 0 ? 'text-amber-400' : 'text-slate-400'}`}>
              {mistakeCount} <span className="text-xs font-normal text-slate-400">手</span>
            </span>
            {stats.currentStreak > 0 && (
              <span className="text-xs font-semibold text-amber-300 flex items-center gap-0.5">
                <Flame className="w-3 h-3 text-amber-400 fill-amber-400" />
                {stats.currentStreak}连对
              </span>
            )}
          </div>
        </div>
        <div className="w-9 h-9 rounded-lg bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
          <Layers className="w-4 h-4" />
        </div>
      </div>
    </div>
  );
};
