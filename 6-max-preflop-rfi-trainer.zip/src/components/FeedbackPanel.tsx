import React from 'react';
import { motion } from 'motion/react';
import { DecisionResult, Position } from '../data/rfiStrategy';
import { CheckCircle2, ShieldAlert, Sparkles, Brain, Cpu } from 'lucide-react';

interface FeedbackPanelProps {
  decision: DecisionResult | null;
  handStr: string;
  position: Position;
  userAction: 'raise' | 'fold' | null;
  isFromQueue: boolean;
  queueStreak?: number;
}

export const FeedbackPanel: React.FC<FeedbackPanelProps> = ({
  decision,
  handStr,
  position,
  userAction,
  queueStreak,
}) => {
  const panelRef = React.useRef<HTMLDivElement>(null);

  React.useEffect(() => {
    if (decision && userAction && panelRef.current) {
      // Smooth scroll into view when feedback is displayed
      panelRef.current.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }
  }, [decision, userAction]);

  if (!decision || !userAction) return null;

  const isCorrect = decision.isCorrect;
  const isRaiseRecommended = decision.recommendedAction === 'raise';
  const isMixed = decision.recommendedAction === 'mixed';

  // Strategy frequencies breakdown
  const raiseFreq = isMixed ? 50 : isRaiseRecommended ? 100 : 0;
  const foldFreq = isMixed ? 50 : isRaiseRecommended ? 0 : 100;

  // Generate tactical analysis based on hand
  const getTacticalAnalysis = () => {
    if (handStr.includes('A') || handStr.includes('K')) {
      return `手牌 [${handStr}] 包含高张阻挡牌（Blocker），能有效降低对手持有 AA/KK 或 AK 3-Bet 的概率。在 ${position} 位置通过 Raise 2.5x 入局可主导翻后头衔。`;
    }
    if (['AA','KK','QQ','JJ','TT','99','88'].includes(handStr)) {
      return `口袋对子 [${handStr}] 拥有直接的暗三条（Set）发展潜力与高牌胜率，处于 ${position} 位的核心首开价值范围。`;
    }
    if (handStr.endsWith('s')) {
      return `同花手牌 [${handStr}] 拥有优异的翻后可塑性（Playability）与强同花听牌胜率，是 ${position} 位置不可或缺的开局加注组合。`;
    }
    return `手牌 [${handStr}] 在 ${position} 位置属于弱组合。翻前直接 Fold 可以有效避免在无位置或无胜率优势下卷入大底池。`;
  };

  const getRangeBlockerAnalysis = () => {
    if (isRaiseRecommended) {
      return `在 6-Max 中，[${position}] 位的首开范围拥有强劲的胜率（Equity）支撑，阻挡了身后盲位对手的 3-Bet 挤压，建立底池控制权。`;
    }
    return `[${position}] 位首开门槛较高，该手牌的反弹胜率（Realization）过低，加注会导致长期负 EV（-mBB/hand）亏损。`;
  };

  return (
    <motion.div
      ref={panelRef}
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -10 }}
      className={`w-full border rounded-xl p-3.5 sm:p-4 shadow-xl text-xs mb-4 scroll-mb-12 ${
        isCorrect
          ? 'bg-[#132822]/90 border-emerald-500/50 text-emerald-100'
          : decision.penaltyLevel === 'blunder'
          ? 'bg-[#2a1318]/90 border-rose-500/50 text-rose-100'
          : 'bg-[#2a2113]/90 border-amber-500/50 text-amber-100'
      }`}
    >
      {/* Header Verdict Bar */}
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-white/10 pb-2.5">
        <div className="flex items-center gap-2">
          {isCorrect ? (
            <div className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
              <CheckCircle2 className="w-4 h-4" />
            </div>
          ) : (
            <div className="w-6 h-6 rounded-full bg-rose-500/20 text-rose-400 flex items-center justify-center">
              <ShieldAlert className="w-4 h-4" />
            </div>
          )}

          <div className="flex items-center gap-2">
            <span className="font-bold text-sm">
              当场判定: {isCorrect ? '✓ 决策正确' : '✗ 决策失误'}
            </span>
            <span className="px-2 py-0.5 rounded font-mono font-bold bg-black/40 border border-white/10 text-[11px]">
              EV {decision.evPenalty === 0 ? '0' : decision.evPenalty} mBB
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-[10px] text-slate-300 font-mono hidden sm:inline">
            {decision.message}
          </span>
          <button
            onClick={() => alert(`【GTO 深度解析】\n手牌: ${handStr}\n位置: ${position}\n${decision.message}`)}
            className="px-2.5 py-1 bg-purple-600/30 hover:bg-purple-600/50 text-purple-300 border border-purple-500/40 rounded flex items-center gap-1 font-bold cursor-pointer transition-all"
          >
            <Cpu className="w-3 h-3 text-purple-400" />
            <span>Gemini AI 深入诊所</span>
          </button>
        </div>
      </div>

      {/* GTO Frequency Action Bar */}
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 my-3">
        <div className="bg-black/30 p-2 rounded border border-white/5 flex flex-col justify-between">
          <div className="flex justify-between text-[10px] text-slate-300 font-bold mb-1">
            <span>标准加注 2.5x BB</span>
            <span className="font-mono text-emerald-400">{raiseFreq}%</span>
          </div>
          <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
            <div className="bg-emerald-500 h-full transition-all duration-300" style={{ width: `${raiseFreq}%` }} />
          </div>
        </div>

        <div className="bg-black/30 p-2 rounded border border-white/5 flex flex-col justify-between">
          <div className="flex justify-between text-[10px] text-slate-300 font-bold mb-1">
            <span>弃牌 Fold ({userAction === 'fold' ? '你的选择' : 'GTO'})</span>
            <span className="font-mono text-rose-400">{foldFreq}%</span>
          </div>
          <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
            <div className="bg-rose-500 h-full transition-all duration-300" style={{ width: `${foldFreq}%` }} />
          </div>
        </div>

        <div className="col-span-2 sm:col-span-1 bg-black/30 p-2 rounded border border-white/5 flex flex-col justify-between">
          <div className="flex justify-between text-[10px] text-slate-300 font-bold mb-1">
            <span>最佳推荐策略</span>
            <span className="font-mono text-amber-400 uppercase">{decision.recommendedAction}</span>
          </div>
          <div className="text-[10px] text-slate-400 truncate">
            {isMixed ? '混合 50% Raise / 50% Fold' : isRaiseRecommended ? '100% Raise 2.5x' : '100% Fold'}
          </div>
        </div>
      </div>

      {/* Strategic Diagnostics Details */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-[11px] leading-relaxed pt-1">
        <div className="bg-black/20 p-2.5 rounded border border-white/5">
          <div className="font-bold text-amber-300 flex items-center gap-1 mb-1">
            <Brain className="w-3.5 h-3.5" />
            <span>【决策诊断与战术原理】:</span>
          </div>
          <p className="text-slate-300">{getTacticalAnalysis()}</p>
        </div>

        <div className="bg-black/20 p-2.5 rounded border border-white/5">
          <div className="font-bold text-teal-300 flex items-center gap-1 mb-1">
            <Sparkles className="w-3.5 h-3.5" />
            <span>【范围与阻挡效应分析】:</span>
          </div>
          <p className="text-slate-300">{getRangeBlockerAnalysis()}</p>
        </div>
      </div>

      {/* Spaced repetition queue streak note */}
      {queueStreak !== undefined && (
        <div className="mt-2 text-[10px] flex items-center gap-1.5 text-amber-300 bg-amber-500/10 px-2 py-1 rounded border border-amber-500/20 font-mono">
          <Sparkles className="w-3 h-3 text-amber-400" />
          <span>错题库强化巩固: 连续答对进度 ({queueStreak}/3) 次即可消除此错题</span>
        </div>
      )}
    </motion.div>
  );
};
