import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MistakeItem } from '../types';
import { X, Layers, Trash2, CheckCircle2, AlertTriangle, RefreshCw } from 'lucide-react';
import { SUIT_SYMBOLS } from '../data/rfiStrategy';

interface MistakeQueueModalProps {
  isOpen: boolean;
  onClose: () => void;
  mistakeQueue: MistakeItem[];
  onRemoveItem: (id: string) => void;
  onClearAll: () => void;
  mistakeFocusMode: boolean;
  onToggleFocusMode: () => void;
}

export const MistakeQueueModal: React.FC<MistakeQueueModalProps> = ({
  isOpen,
  onClose,
  mistakeQueue,
  onRemoveItem,
  onClearAll,
  mistakeFocusMode,
  onToggleFocusMode,
}) => {
  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 10 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 10 }}
          className="w-full max-w-xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh]"
        >
          {/* Header */}
          <div className="flex items-center justify-between p-4 sm:p-5 border-b border-slate-800 bg-slate-950/50">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
                <Layers className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
                  漏水错题库 (间隔重复)
                  <span className="px-2 py-0.5 bg-amber-500/20 text-amber-300 rounded-full text-xs font-semibold">
                    {mistakeQueue.length} 手锁定
                  </span>
                </h2>
                <p className="text-xs text-slate-400">
                  发牌时有 30% 概率优先抽取错题 • 连续答对 3 次后自动解锁移出
                </p>
              </div>
            </div>

            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Body List */}
          <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-2.5">
            {mistakeQueue.length === 0 ? (
              <div className="text-center py-12 text-slate-500">
                <CheckCircle2 className="w-12 h-12 text-emerald-500/40 mx-auto mb-3" />
                <p className="text-sm font-semibold text-slate-300">错题库空空如也！</p>
                <p className="text-xs text-slate-500 mt-1">你在训练中犯错的手牌会自动锁定记录在此。</p>
              </div>
            ) : (
              mistakeQueue.map((item) => (
                <div
                  key={item.id}
                  className="flex items-center justify-between p-3 bg-slate-800/60 border border-slate-700/60 rounded-xl hover:border-slate-600 transition-all"
                >
                  <div className="flex items-center gap-3">
                    <span className="px-2.5 py-1 bg-blue-500/20 text-blue-300 border border-blue-500/30 font-bold text-xs rounded-lg">
                      {item.position}
                    </span>

                    <div className="flex items-center gap-1.5 bg-white text-slate-900 px-2 py-1 rounded border border-slate-300 text-xs font-bold font-mono">
                      <span>{item.combo.card1.rank}{SUIT_SYMBOLS[item.combo.card1.suit]}</span>
                      <span>{item.combo.card2.rank}{SUIT_SYMBOLS[item.combo.card2.suit]}</span>
                      <span className="text-slate-500 font-sans ml-1 text-[10px]">({item.handStr})</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    {/* Streak Counter */}
                    <div className="flex items-center gap-1 bg-slate-900/80 px-2.5 py-1 rounded-lg border border-slate-700 text-xs font-medium">
                      <span className="text-slate-400">正确进度:</span>
                      <span className="font-extrabold text-amber-400">{item.streak}/3</span>
                    </div>

                    <button
                      onClick={() => onRemoveItem(item.id)}
                      className="p-1.5 text-slate-400 hover:text-rose-400 rounded-lg hover:bg-rose-500/10 transition-colors"
                      title="移除此错题"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Footer */}
          <div className="p-4 border-t border-slate-800 bg-slate-950/40 flex flex-wrap items-center justify-between gap-2">
            <button
              onClick={onToggleFocusMode}
              className={`flex items-center gap-2 px-3 py-1.5 text-xs font-bold rounded-lg border transition-all ${
                mistakeFocusMode
                  ? 'bg-amber-500 text-slate-950 border-amber-400 shadow-md shadow-amber-500/20 animate-pulse'
                  : 'bg-slate-800 text-amber-300 border-amber-500/40 hover:bg-slate-700'
              }`}
            >
              <RefreshCw className={`w-3.5 h-3.5 ${mistakeFocusMode ? 'animate-spin' : ''}`} />
              <span>{mistakeFocusMode ? '🔥 错题特训模式已开启 (100% 专攻)' : '开启 100% 错题特训模式'}</span>
            </button>

            {mistakeQueue.length > 0 && (
              <button
                onClick={onClearAll}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-rose-300 bg-rose-950/40 hover:bg-rose-900/60 border border-rose-600/40 rounded-lg transition-all"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>清空错题库</span>
              </button>
            )}
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
