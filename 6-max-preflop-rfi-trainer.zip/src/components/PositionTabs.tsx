import React from 'react';
import { Position } from '../data/rfiStrategy';

interface PositionTabsProps {
  currentPosition: Position;
  onSelectPosition: (pos: Position) => void;
}

const POSITIONS: { pos: Position; label: string; frequency: string }[] = [
  { pos: 'UTG', label: 'UTG 枪口', frequency: '16.8%' },
  { pos: 'MP', label: 'MP 中间', frequency: '20.1%' },
  { pos: 'CO', label: 'CO 关口', frequency: '27.2%' },
  { pos: 'BTN', label: 'BTN 庄家', frequency: '43.8%' },
  { pos: 'SB', label: 'SB 小盲', frequency: '48.5%' },
];

export const PositionTabs: React.FC<PositionTabsProps> = ({
  currentPosition,
  onSelectPosition,
}) => {
  return (
    <div className="flex items-center gap-1.5 bg-slate-800/90 p-1 rounded-lg border border-slate-700/80 shadow-inner">
      {POSITIONS.map(({ pos, label, frequency }) => {
        const isActive = currentPosition === pos;
        return (
          <button
            key={pos}
            onClick={() => onSelectPosition(pos)}
            className={`px-3 py-1.5 text-xs font-bold rounded transition-all cursor-pointer flex items-center gap-1.5 ${
              isActive
                ? 'bg-emerald-500 text-white shadow-md'
                : 'bg-slate-700/60 hover:bg-slate-700 text-slate-300'
            }`}
          >
            <span>{pos}</span>
            <span
              className={`text-[10px] font-mono px-1 rounded ${
                isActive ? 'bg-black/20 text-emerald-100' : 'bg-slate-800 text-slate-400'
              }`}
            >
              {frequency}
            </span>
          </button>
        );
      })}
    </div>
  );
};

