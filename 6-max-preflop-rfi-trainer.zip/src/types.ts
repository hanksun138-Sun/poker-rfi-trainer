import { Position, Card, Combo, DecisionResult } from './data/rfiStrategy';

export type DeckSuitStyle = '4color' | '2color';

export interface MistakeItem {
  id: string;
  position: Position;
  handStr: string;
  combo: Combo;
  streak: number; // 0 to 3 consecutive correct answers required to remove
  createdAt: number;
}

export interface TrainingStats {
  totalHands: number;
  correctCount: number;
  totalEVLoss: number; // in mBB
  currentStreak: number;
  bestStreak: number;
}

export interface HandHistory {
  id: string;
  position: Position;
  combo: Combo;
  userAction: 'raise' | 'fold';
  decision: DecisionResult;
  timestamp: number;
  isFromQueue: boolean;
}
