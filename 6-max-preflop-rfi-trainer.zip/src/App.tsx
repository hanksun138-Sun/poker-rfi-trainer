import React, { useState, useEffect, useCallback } from 'react';
import {
  Position,
  Combo,
  DecisionResult,
  getAll1326Combos,
  evaluateDecision,
  SUIT_SYMBOLS,
} from './data/rfiStrategy';
import { TrainingStats, MistakeItem, DeckSuitStyle } from './types';
import { Header } from './components/Header';
import { PositionTabs } from './components/PositionTabs';
import { TablePokerCards } from './components/TablePokerCards';
import { ActionControls } from './components/ActionControls';
import { FeedbackPanel } from './components/FeedbackPanel';
import { RangeMatrix } from './components/RangeMatrix';
import { RangeMatrixDropdown } from './components/RangeMatrixDropdown';
import { MistakeQueueModal } from './components/MistakeQueueModal';
import { Trash2, Layers, AlertCircle, Sparkles } from 'lucide-react';

export default function App() {
  const [currentPosition, setCurrentPosition] = useState<Position>('UTG');
  const [combos] = useState<Combo[]>(() => getAll1326Combos());
  const [currentCombo, setCurrentCombo] = useState<Combo | null>(null);
  const [isFromQueue, setIsFromQueue] = useState<boolean>(false);

  const [isAnswered, setIsAnswered] = useState<boolean>(false);
  const [userAction, setUserAction] = useState<'raise' | 'fold' | null>(null);
  const [currentDecision, setCurrentDecision] = useState<DecisionResult | null>(null);

  const [deckStyle, setDeckStyle] = useState<DeckSuitStyle>('4color');
  const [isQueueModalOpen, setIsQueueModalOpen] = useState<boolean>(false);

  // Statistics State
  const [stats, setStats] = useState<TrainingStats>({
    totalHands: 0,
    correctCount: 0,
    totalEVLoss: 0,
    currentStreak: 0,
    bestStreak: 0,
  });

  // Mistake Queue State & Mode
  const [mistakeQueue, setMistakeQueue] = useState<MistakeItem[]>([]);
  const [mistakeFocusMode, setMistakeFocusMode] = useState<boolean>(false);

  // Deal Next Hand Logic
  const dealNextHand = useCallback(
    (pos: Position = currentPosition) => {
      setIsAnswered(false);
      setUserAction(null);
      setCurrentDecision(null);

      const posMistakes = mistakeQueue.filter((m) => m.position === pos);
      const allMistakes = mistakeQueue;

      // Determine whether to pick from mistake queue
      let pickFromQueue = false;

      if (mistakeFocusMode) {
        // 100% Focus mode: pick from position mistakes if available, or any mistake in queue
        pickFromQueue = allMistakes.length > 0;
      } else {
        // Standard mode: 30% chance if position has mistakes
        pickFromQueue = posMistakes.length > 0 && Math.random() < 0.3;
      }

      if (pickFromQueue) {
        const pool = posMistakes.length > 0 ? posMistakes : allMistakes;
        const picked = pool[Math.floor(Math.random() * pool.length)];
        // Automatically switch position tab if picked hand is from another position in 100% focus mode
        if (picked.position !== pos) {
          setCurrentPosition(picked.position);
        }
        setCurrentCombo(picked.combo);
        setIsFromQueue(true);
      } else {
        const randomIndex = Math.floor(Math.random() * combos.length);
        setCurrentCombo(combos[randomIndex]);
        setIsFromQueue(false);
      }
    },
    [combos, currentPosition, mistakeQueue, mistakeFocusMode]
  );

  // Initial Deal on Load
  useEffect(() => {
    dealNextHand('UTG');
  }, []);

  // Position Switch Handler
  const handleSelectPosition = (pos: Position) => {
    setCurrentPosition(pos);
    dealNextHand(pos);
  };

  // Evaluate Decision Handler
  const handleUserAction = (action: 'raise' | 'fold') => {
    if (isAnswered || !currentCombo) return;

    setUserAction(action);
    setIsAnswered(true);

    const decision = evaluateDecision(currentPosition, currentCombo.handStr, action);
    setCurrentDecision(decision);

    // Update Statistics
    setStats((prev) => {
      const newTotal = prev.totalHands + 1;
      const newCorrect = prev.correctCount + (decision.isCorrect ? 1 : 0);
      const newEVLoss = prev.totalEVLoss + Math.abs(decision.evPenalty);
      const newStreak = decision.isCorrect ? prev.currentStreak + 1 : 0;
      const newBestStreak = Math.max(prev.bestStreak, newStreak);

      return {
        totalHands: newTotal,
        correctCount: newCorrect,
        totalEVLoss: newEVLoss,
        currentStreak: newStreak,
        bestStreak: newBestStreak,
      };
    });

    // Handle Mistake Queue logic
    const existingQueueItem = mistakeQueue.find(
      (m) => m.position === currentPosition && m.handStr === currentCombo.handStr
    );

    if (decision.isCorrect) {
      if (existingQueueItem) {
        const updatedStreak = existingQueueItem.streak + 1;
        if (updatedStreak >= 3) {
          // Remove from mistake queue after 3 consecutive correct answers
          setMistakeQueue((prev) => prev.filter((m) => m.id !== existingQueueItem.id));
        } else {
          // Update streak
          setMistakeQueue((prev) =>
            prev.map((m) => (m.id === existingQueueItem.id ? { ...m, streak: updatedStreak } : m))
          );
        }
      }
    } else {
      // Incorrect decision: Add or reset streak in mistake queue
      if (existingQueueItem) {
        setMistakeQueue((prev) =>
          prev.map((m) => (m.id === existingQueueItem.id ? { ...m, streak: 0 } : m))
        );
      } else {
        const newItem: MistakeItem = {
          id: `${currentPosition}-${currentCombo.handStr}-${Date.now()}`,
          position: currentPosition,
          handStr: currentCombo.handStr,
          combo: currentCombo,
          streak: 0,
          createdAt: Date.now(),
        };
        setMistakeQueue((prev) => [...prev, newItem]);
      }
    }
  };

  // Global Keyboard Shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (['INPUT', 'TEXTAREA', 'SELECT'].includes((e.target as HTMLElement)?.tagName)) {
        return;
      }

      if (e.key === 'f' || e.key === 'F' || e.key === 'ArrowLeft') {
        if (!isAnswered) {
          e.preventDefault();
          handleUserAction('fold');
        }
      } else if (e.key === 'r' || e.key === 'R' || e.key === 'ArrowRight') {
        if (!isAnswered) {
          e.preventDefault();
          handleUserAction('raise');
        }
      } else if (e.code === 'Space') {
        e.preventDefault();
        if (isAnswered) {
          dealNextHand();
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isAnswered, dealNextHand]);

  // Reset Stats
  const handleResetStats = () => {
    if (window.confirm('确定要重置所有训练数据统计吗？')) {
      setStats({
        totalHands: 0,
        correctCount: 0,
        totalEVLoss: 0,
        currentStreak: 0,
        bestStreak: 0,
      });
    }
  };

  // Current queue item streak for feedback panel
  const currentQueueItem = mistakeQueue.find(
    (m) => currentCombo && m.position === currentPosition && m.handStr === currentCombo.handStr
  );

  return (
    <div className="min-h-screen bg-[#0F172A] text-slate-100 flex flex-col font-sans select-none overflow-x-hidden">
      {/* Top Header */}
      <Header
        stats={stats}
        onResetStats={handleResetStats}
        onOpenMistakeQueue={() => setIsQueueModalOpen(true)}
        mistakeCount={mistakeQueue.length}
      />

      {/* Main Container Full Width Table View */}
      <div className="w-full max-w-6xl mx-auto flex-1 p-3 sm:p-5 pb-12 sm:pb-16 flex flex-col gap-4">
        {/* Sub-bar: Position selector, Range Matrix Dropdown & Mode Toggle */}
        <div className="w-full flex flex-wrap items-center justify-between gap-3 bg-[#1E293B] p-3 rounded-2xl border border-slate-700/80 shadow-xl">
          <PositionTabs
            currentPosition={currentPosition}
            onSelectPosition={handleSelectPosition}
          />

          <div className="flex flex-wrap items-center gap-2 sm:gap-3 text-xs font-mono">
            {/* Dropdown Menu to Query GTO Matrix */}
            <RangeMatrixDropdown
              currentTrainingPosition={currentPosition}
              currentHandStr={currentCombo?.handStr || null}
            />

            <button
              onClick={() => setMistakeFocusMode((prev) => !prev)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border transition-all text-xs font-bold cursor-pointer shadow-sm ${
                mistakeFocusMode
                  ? 'bg-amber-500 text-slate-950 border-amber-400 shadow-md shadow-amber-500/20 animate-pulse'
                  : 'bg-slate-800 text-slate-300 border-slate-700 hover:border-amber-500/50 hover:text-amber-400'
              }`}
              title="点击切换训练模式"
            >
              <span>{mistakeFocusMode ? '🔥 错题特训模式 (100% 专注错题)' : '⚡ 标准抽查 (30% 错题插队)'}</span>
            </button>

            <span className="hidden lg:inline text-slate-500">•</span>
            <span className="hidden lg:inline text-slate-400">最佳连对: <strong className="text-amber-400">{stats.bestStreak}</strong></span>
          </div>
        </div>

        {/* Main Poker Table Workspace (Occupies Full Screen Width) */}
        <div className="w-full flex flex-col items-center gap-4 flex-1">
          <TablePokerCards
            combo={currentCombo}
            position={currentPosition}
            isFromQueue={isFromQueue}
            deckStyle={deckStyle}
            onToggleDeckStyle={() => setDeckStyle((prev) => (prev === '4color' ? '2color' : '4color'))}
            onSelectPosition={handleSelectPosition}
          />

          <ActionControls
            isAnswered={isAnswered}
            onAction={handleUserAction}
            onNext={() => dealNextHand()}
          />

          <FeedbackPanel
            decision={currentDecision}
            handStr={currentCombo?.handStr || ''}
            position={currentPosition}
            userAction={userAction}
            isFromQueue={isFromQueue}
            queueStreak={currentQueueItem?.streak}
          />

          {/* Compact Live Mistake Queue Banner (If mistakes exist) */}
          {mistakeQueue.length > 0 && (
            <div className="w-full max-w-3xl bg-[#1E293B]/90 border border-amber-500/30 rounded-xl p-2.5 sm:px-4 shadow-md flex items-center justify-between gap-2 mt-1">
              <div className="flex items-center gap-2">
                <Layers className="w-4 h-4 text-amber-400 animate-bounce" />
                <span className="text-xs font-bold text-slate-200">
                  漏水错题库累计 <strong className="text-amber-400 font-mono">{mistakeQueue.length}</strong> 题
                </span>
                <span className="hidden sm:inline text-[11px] text-slate-400">
                  (连续答对 3 次将自动解封)
                </span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setIsQueueModalOpen(true)}
                  className="px-2.5 py-1 bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 border border-amber-500/30 rounded-lg text-xs font-semibold transition-all cursor-pointer"
                >
                  查看并重练错题 →
                </button>
                <button
                  onClick={() => {
                    if (window.confirm('确定要清空错题库吗？')) setMistakeQueue([]);
                  }}
                  className="p-1 text-slate-400 hover:text-rose-400 transition-colors"
                  title="清空错题"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Bottom Footer / Hotkey Hint Bar */}
      <footer className="w-full bg-[#1E293B] border-t border-slate-700/80 px-4 py-2 text-xs text-slate-400 flex flex-wrap items-center justify-between gap-2 shadow-inner">
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span className="font-mono text-[11px]">1326 COMBOS LOADED • SPACED REPETITION ACTIVE</span>
        </div>

        <div className="flex items-center gap-3 font-mono text-[11px]">
          <span>快捷键:</span>
          <span className="flex items-center gap-1">
            <kbd className="px-1.5 py-0.5 bg-slate-800 text-slate-200 border border-slate-600 rounded text-[10px]">F</kbd> Fold
          </span>
          <span className="flex items-center gap-1">
            <kbd className="px-1.5 py-0.5 bg-slate-800 text-slate-200 border border-slate-600 rounded text-[10px]">R</kbd> Raise
          </span>
          <span className="flex items-center gap-1">
            <kbd className="px-1.5 py-0.5 bg-slate-800 text-slate-200 border border-slate-600 rounded text-[10px]">SPACE</kbd> Next
          </span>
        </div>
      </footer>

      {/* Full Modal Drawer */}
      <MistakeQueueModal
        isOpen={isQueueModalOpen}
        onClose={() => setIsQueueModalOpen(false)}
        mistakeQueue={mistakeQueue}
        mistakeFocusMode={mistakeFocusMode}
        onToggleFocusMode={() => setMistakeFocusMode((prev) => !prev)}
        onRemoveItem={(id) => setMistakeQueue((prev) => prev.filter((m) => m.id !== id))}
        onClearAll={() => {
          if (window.confirm('确定要清空漏水错题库吗？')) {
            setMistakeQueue([]);
          }
        }}
      />
    </div>
  );
}

